import React, { Component } from 'react';
import ReactTable from "react-table-6";
import "react-table-6/react-table.css";
import axios from 'axios'
class App extends Component {
  state = {
    data: []
  }
  componentDidMount() {

    axios.get('http://localhost:9090/dating-app/e-dating/api/v1/users/get/all')
      .then(response => {this.setState({ data: response.data })
    console.log('Response Data',response);
    });
  }
  render() {

    const columns = [
      {
        Header: 'Sl.no',
        accessor: 'userId'
      },
      {
      Header: 'Name',
      accessor: 'name'
    }, {
      Header: 'Age',
      accessor: 'age'
    },
    {
      Header: 'PhoneNumber',
      accessor: 'phoneNumber'
    },
    {
      Header: 'Gender',
      accessor: 'gender'
    },
    {
      Header: 'E-mail',
      accessor: 'email'
    },
    {
      Header: 'City',
      accessor: 'city'
    },
    {
      Header: 'Country',
      accessor: 'country'
    }]
    return (
      <div>

        <ReactTable
          data={this.state.data}
          columns={columns}
          defaultPageSize={2}
          pageSizeOptions={[2, 4, 6, 8]}
        />
      </div>
    )
  }
}
export default App; 