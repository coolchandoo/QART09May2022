package com.iiht.training.datingapp.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.iiht.training.datingapp.entity.User;

@Repository
public interface UserRepository extends JpaRepository<User, String> {
	
	@Query(value="select interest from public.dating_user where user_name=:username",nativeQuery = true)	
	public Long findInterestByUserName(String username);
	
	@Query(value="select u from User u  where u.userName=:username")	
	public User findbyuserName(String username);

}
