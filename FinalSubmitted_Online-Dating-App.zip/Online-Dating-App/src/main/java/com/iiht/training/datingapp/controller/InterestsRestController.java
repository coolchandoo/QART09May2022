package com.iiht.training.datingapp.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.iiht.training.datingapp.dto.InterestsDto;
import com.iiht.training.datingapp.exceptions.InvalidDataException;
import com.iiht.training.datingapp.exceptions.UserNotFoundException;
import com.iiht.training.datingapp.service.InterestsService;

@RestController
@RequestMapping("/e-dating/api/v1/interests")
public class InterestsRestController {

	@Autowired
	private InterestsService interestsService;


	// 2nd end point

	@PutMapping("/update")
	public ResponseEntity<InterestsDto> updateInterests(@Valid @RequestBody InterestsDto interestsDto,
			BindingResult result) {

		if (!interestsDto.getProfileUrl().startsWith("http")) {
			throw new UserNotFoundException("Invalid Interest ID");
		} else {
			InterestsDto interestResult = interestsService.updateInterest(interestsDto);
			return new ResponseEntity<>(interestResult, HttpStatus.OK);
		}
	}

// 5th endpoint
	@DeleteMapping("/{interestId}")
	public ResponseEntity<Boolean> deleteInterests(@PathVariable Long interestId) {
		if (interestId != 0) {
			interestsService.deleteInterest(interestId);
			return new ResponseEntity<>(true, HttpStatus.OK);
		}
		else {
			return new ResponseEntity<>(false, HttpStatus.OK);
		}
	}

}
