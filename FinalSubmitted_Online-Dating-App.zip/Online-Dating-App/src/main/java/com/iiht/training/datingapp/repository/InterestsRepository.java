package com.iiht.training.datingapp.repository;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

import javax.transaction.Transactional;

import com.iiht.training.datingapp.entity.Interests;

@Repository
public interface InterestsRepository extends CrudRepository<Interests, Long> {

	@Query("select d from Interests d where d.userName=:userName")
	List<Interests> findbyUserId(String userName);

	@Query("select d from Interests d where d.interestId=:interestId")
	Interests findbyInterestId(Long interestId);

	@Transactional
	@Modifying
	@Query(value = "delete from public.interests_hobbies where interests_interest_id=:id", nativeQuery = true)
	void deleteInterestsHobbies(Long id);

	@Transactional
	@Modifying
	@Query(value = "delete from public.dating_user where interest=:id", nativeQuery = true)
	void deleteUser(Long id);

}
