package com.iiht.training.datingapp.service;

import java.util.List;
import com.iiht.training.datingapp.dto.UserDto;
import com.iiht.training.datingapp.filter.Filter;

public interface UserService {

	public UserDto registerUser(UserDto user);
	
	public List<UserDto> findAll();
	
	public List<UserDto> getPotentialMatches(String userName, List<Filter> filters);

}
