package com.iiht.training.datingapp.filter;

import java.util.ArrayList;
import java.util.List;
import com.iiht.training.datingapp.dto.UserDto;
import com.iiht.training.datingapp.exceptions.InvalidDataException;

public class FilterUtils {

	private FilterUtils() {

	}

	public static List<UserDto> applyAgeFilter(List<UserDto> filteredUsers, List<?> values) {
		
		if(values.size()==2) {
		int startAge = (Integer) values.get(0);
		int endAge = (Integer) values.get(1);
		List<UserDto> ageFiltered = new ArrayList<>();
		filteredUsers.forEach(user -> {
			if (user.getAge() >= startAge && user.getAge() <= endAge) {
				ageFiltered.add(user);
			}
		});
		return ageFiltered;
		}
		else {
			throw new InvalidDataException("Kindly Provide min and max age");
		}
	}

	public static List<UserDto> applyLocationFilter(List<UserDto> filteredUsers, List<?> values, boolean byCity) {
		String location = values.get(0).toString();
		List<UserDto> locationFiltered = new ArrayList<>();
		filteredUsers.forEach(user -> {
			String userLocation = byCity ? user.getCity() : user.getCountry();
			if (userLocation.equalsIgnoreCase(location)) {
				locationFiltered.add(user);
			}
		});
		return locationFiltered;
	}

	public static List<UserDto> applyGenderFilter(List<UserDto> filteredUsers, List<?> values) {
		if(values.size()<2) {
		String gender = values.get(0).toString();
		List<UserDto> genderFiltered = new ArrayList<>();
		filteredUsers.forEach(user -> {
			String userSex = user.getGender();
			if (userSex.equals(gender)) {
				genderFiltered.add(user);
			}
		});
		return genderFiltered;}
		else {
			throw new InvalidDataException("Please provide any one Gender");
		}
	}

	
}