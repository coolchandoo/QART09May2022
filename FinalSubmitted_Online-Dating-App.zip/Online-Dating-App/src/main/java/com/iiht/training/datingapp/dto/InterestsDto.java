package com.iiht.training.datingapp.dto;

import java.util.List;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Length;

public class InterestsDto {

	private Long interestId;
	@NotBlank
	private String userName;
	@NotBlank
	@Length(min = 3, max = 100)
	private String likes;
	@NotBlank
	@Length(min = 3, max = 100)
	private String dislikes;
	@NotEmpty
	private List<String> hobbies;
	@NotBlank
	@Pattern(regexp = "^(https?)://.*$", message = "Url Should Start with http or https")
	private String profileUrl;
	@NotBlank
	@Length(min = 3, max = 100)
	private String about;

	public Long getInterestId() {
		return interestId;
	}

	public void setInterestId(Long interestId) {
		this.interestId = interestId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	

	public String getLikes() {
		return likes;
	}

	public void setLikes(String likes) {
		this.likes = likes;
	}

	public String getDislikes() {
		return dislikes;
	}

	public void setDislikes(String dislikes) {
		this.dislikes = dislikes;
	}

	public List<String> getHobbies() {
		return hobbies;
	}

	public void setHobbies(List<String> hobbies) {
		this.hobbies = hobbies;
	}

	public String getProfileUrl() {
		return profileUrl;
	}

	public void setProfileUrl(String profileUrl) {
		this.profileUrl = profileUrl;
	}

	public String getAbout() {
		return about;
	}

	public void setAbout(String about) {
		this.about = about;
	}

}
