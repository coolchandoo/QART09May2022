package com.iiht.training.datingapp.service.impl;

import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.iiht.training.datingapp.dto.InterestsDto;
import com.iiht.training.datingapp.entity.Interests;
import com.iiht.training.datingapp.entity.User;
import com.iiht.training.datingapp.exceptions.InvalidDataException;
import com.iiht.training.datingapp.repository.InterestsRepository;
import com.iiht.training.datingapp.repository.UserRepository;
import com.iiht.training.datingapp.service.InterestsService;

@Service
public class InterestsServiceImpl implements InterestsService {

	@Autowired
	private InterestsRepository interestsRepository;

	@Autowired
	private UserRepository userRepo;;

	@Override
	public InterestsDto updateInterest(InterestsDto interestsDto) {
		if (interestsDto.getInterestId() != 0) {
			User findbyuserName = userRepo.findbyuserName(interestsDto.getUserName());
			if (findbyuserName != null) {
			Interests interestRecord = interestsRepository.findbyInterestId(interestsDto.getInterestId());
				if (interestRecord!=null) {
					Interests interest = new Interests();
					BeanUtils.copyProperties(interestsDto, interest);
					interestsRepository.save(interest);
					return interestsDto;
				} else {
					throw new InvalidDataException("Interest Id doesn't Exist..Please provide valid interestId");
				}

			} else {
				throw new InvalidDataException("User Not found...");
			}
		}
		else {
			throw new InvalidDataException("Not a valid Data");
		}
	}

	@Override
	public boolean deleteInterest(Long interestId) {

		if (interestId != 0) {

			interestsRepository.deleteById(interestId);
			return true;
		} else {
			return false;
		}

	}

}
