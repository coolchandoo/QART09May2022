package com.iiht.training.datingapp.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.iiht.training.datingapp.dto.UserDto;
import com.iiht.training.datingapp.exceptions.InvalidDataException;
import com.iiht.training.datingapp.filter.Filter;
import com.iiht.training.datingapp.service.UserService;

@RestController
@RequestMapping("/e-dating/api/v1")
@CrossOrigin("http://localhost:3000")
public class UserRestController {

	@Autowired
	private UserService userService;
	
	// 1St End Point

	@PostMapping("/users/register-user")
	public ResponseEntity<UserDto> saveUser(@Valid @RequestBody UserDto userDto, BindingResult result) {

		if (userDto.getUserName().length()<3) {
			throw new InvalidDataException("Invalid User Data");
		}
		
		if(result.hasErrors()) {
			throw new InvalidDataException("Invalid User Data, Check Data");
		}
		userService.registerUser(userDto);
		return new ResponseEntity<>(userDto, HttpStatus.OK);

	}
	
	// 3rd End point
	@PostMapping("/matches/{userName}")
	public List<UserDto> getCandidates(@PathVariable String userName,@RequestBody List<Filter> filters) {
		 List<UserDto> potentialMatches = userService.getPotentialMatches(userName, filters);
		 if(potentialMatches.isEmpty()) {
			 throw new InvalidDataException("No Matches Found...Please change serach criteria");
		 }
		 else {
			 return potentialMatches;
		 }
	}

// 4th end point
	@SuppressWarnings("rawtypes")
	@GetMapping("/users/get/all")
	public ResponseEntity getUsers() {
		List<UserDto> list = userService.findAll();		
			return new ResponseEntity<>(list, HttpStatus.OK);

	}

}
