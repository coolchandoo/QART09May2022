package com.iiht.training.datingapp.model.exception;

public class ExceptionResponse {
	private String message;
	@SuppressWarnings("unused")
	private Long timeStamp;
	private Integer status;

	

	public ExceptionResponse(String message, Long timeStamp, Integer status) {
		super();
		this.message = message;
		this.timeStamp = timeStamp;
		this.status = status;
	}

	public String getMessage() {
		return message;
	}

	

	

	public Integer getStatus() {
		return status;
	}

	

	
}
