package com.iiht.training.datingapp.filter;

import java.util.ArrayList;
import java.util.List;

public class Filter {

	private FilterType type;
	private List<?> values = new ArrayList<>();

	public enum FilterType {
		AGE, CITY, COUNTRY, GENDER;
	}

	public Filter() {
	}

	public Filter(FilterType type, List<?> values) {
		super();
		this.type = type;
		this.values = values;
	}

	public FilterType getType() {
		return type;
	}

	public void setType(FilterType type) {
		this.type = type;
	}

	@SuppressWarnings("rawtypes")
	public List getValues() {
		return values;
	}

	public void setValues(List<?> values) {
		this.values = values;
	}

	
	
	
}
