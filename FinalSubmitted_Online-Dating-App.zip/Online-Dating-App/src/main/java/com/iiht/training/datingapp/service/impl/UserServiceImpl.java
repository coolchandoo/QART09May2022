package com.iiht.training.datingapp.service.impl;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.iiht.training.datingapp.dto.InterestsDto;
import com.iiht.training.datingapp.dto.UserDto;
import com.iiht.training.datingapp.entity.Interests;
import com.iiht.training.datingapp.entity.User;
import com.iiht.training.datingapp.exceptions.InvalidDataException;
import com.iiht.training.datingapp.filter.Filter;

import com.iiht.training.datingapp.repository.InterestsRepository;


import com.iiht.training.datingapp.repository.UserRepository;
import com.iiht.training.datingapp.service.LocationServiceApi;
import com.iiht.training.datingapp.service.UserService;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepository repository;



	@Autowired
	LocationServiceApi locationServiceApi;

	

	@Autowired
	InterestsRepository interestRepo;
	
	

	@Override
	public UserDto registerUser(UserDto userDto) {
		if (userDto != null) {
			User user = new User();
			Interests interest = new Interests();
			BeanUtils.copyProperties(userDto.getInterests(), interest);
			BeanUtils.copyProperties(userDto, user);
			Interests save = interestRepo.save(interest);
			user.setInterests(save);
			repository.save(user);
			return userDto;
		} else {
			throw new InvalidDataException("Invalid data");
		}
	}

	@Override
	public List<UserDto> findAll() {
		List<User> users = repository.findAll();
		List<UserDto> usersDto = new ArrayList<>();
		for (User user : users) {
			Long interestId = repository.findInterestByUserName(user.getUserName());
			Interests interest = interestRepo.findbyInterestId(interestId);
			InterestsDto interestDTO = null;
			if (interest!=null) {
				interestDTO = new InterestsDto();
				BeanUtils.copyProperties(interest, interestDTO);
			}
			UserDto userDto = new UserDto();
			BeanUtils.copyProperties(user, userDto);
			userDto.setInterests(interestDTO);
			usersDto.add(userDto);
		}
		return usersDto;
	}

	@Override
	public List<UserDto> getPotentialMatches(String userName, List<Filter> filters) {
		if (userName != null) {
			User userRecord = repository.findbyuserName(userName);
			if(userRecord!=null) {
			return locationServiceApi.getUsersDto(filters);			
			}
			else {
				throw new InvalidDataException("User Not found...");
			}
		} else {
			throw new InvalidDataException("Invalid User Id");
		}
	}

}
