package com.iiht.training.datingapp.entity;

import java.util.List;

import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Interests {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long interestId;
	private String likes;
	private String dislikes;
	@ElementCollection
	private List<String> hobbies;
	private String profileUrl;
	private String about;

	private String userName;

	public String getAbout() {
		return about;
	}

	public List<String> getHobbies() {
		return hobbies;
	}

	public Long getInterestId() {
		return interestId;
	}

	public String getProfileUrl() {
		return profileUrl;
	}


	public String getLikes() {
		return likes;
	}

	public void setLikes(String likes) {
		this.likes = likes;
	}

	public String getDislikes() {
		return dislikes;
	}

	public void setDislikes(String dislikes) {
		this.dislikes = dislikes;
	}

	public String getUserName() {
		return userName;
	}

	public void setAbout(String about) {
		this.about = about;
	}

	public void setHobbies(List<String> hobbies) {
		this.hobbies = hobbies;
	}

	public void setInterestId(Long interestId) {
		this.interestId = interestId;
	}

	public void setProfileUrl(String profileUrl) {
		this.profileUrl = profileUrl;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

}
