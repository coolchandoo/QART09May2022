package com.iiht.training.datingapp.functional;

import static com.iiht.training.datingapp.testutils.TestUtils.businessTestFile;
import static com.iiht.training.datingapp.testutils.TestUtils.currentTest;
import static com.iiht.training.datingapp.testutils.TestUtils.exceptionTestFile;
import static com.iiht.training.datingapp.testutils.TestUtils.testReport;
import static com.iiht.training.datingapp.testutils.TestUtils.yakshaAssert;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.AfterAll;
//import org.junit.Test;
//import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
//import org.junit.runner.RunWith;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.iiht.training.datingapp.controller.InterestsRestController;
import com.iiht.training.datingapp.dto.InterestsDto;
import com.iiht.training.datingapp.service.InterestsService;
import com.iiht.training.datingapp.testutils.MasterData;

@WebMvcTest(InterestsRestController.class)
@AutoConfigureMockMvc
public class InterestsRestControllerTest {
    @Autowired
    private MockMvc mockMvc;
    

    @MockBean
    private InterestsService interestsService;

    @AfterAll
    public static void afterAll() {
        testReport();
    }

   

    @Test
     void testDeleteInterest() throws Exception {
        InterestsDto interestsDto = MasterData.getInterestsDto();
        interestsDto.setInterestId(1L);
        when(this.interestsService.deleteInterest(1L)).thenReturn(true);
        RequestBuilder requestBuilder = MockMvcRequestBuilders.delete("/e-dating/api/v1/interests/1")
                .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        System.out.println(MasterData.asJsonString(interestsDto));
        System.out.println(result.getResponse().getContentAsString());
        yakshaAssert(currentTest(),
                (result.getResponse().getContentAsString().contentEquals(MasterData.asJsonString(true)) ? "true"
                        : "false"),
                businessTestFile);

    }
    
    @Test
     void testDeleteInterestInvalidData() throws Exception {
        InterestsDto interestsDto = MasterData.getInterestsDto();
        interestsDto.setInterestId(1L);
        when(this.interestsService.deleteInterest(1L)).thenReturn(true);
        RequestBuilder requestBuilder = MockMvcRequestBuilders.delete("/e-dating/api/v1/interests/0")
                .contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        yakshaAssert(currentTest(),
				(result.getResponse().getStatus() == HttpStatus.BAD_REQUEST.value() ? "true" : "false"),
				exceptionTestFile);

    }
    
    

    

    @Test
     void testUpdateInterest() throws Exception {
        InterestsDto interestsDto = MasterData.getInterestsDto();
        InterestsDto savedInterestsDto = MasterData.getInterestsDto();
        when(this.interestsService.updateInterest(interestsDto)).thenReturn(savedInterestsDto);
        RequestBuilder requestBuilder = MockMvcRequestBuilders.put("/e-dating/api/v1/interests/update")
                .content(MasterData.asJsonString(interestsDto)).contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        yakshaAssert(currentTest(),
                (result.getResponse().getContentAsString().contentEquals(MasterData.asJsonString(savedInterestsDto))
                        ? "true"
                        : "false"),
                businessTestFile);

    }
    
    @Test
    void testUpdateInterestInvalidData() throws Exception {
       InterestsDto interestsDto = MasterData.getInterestsDto();
       interestsDto.setProfileUrl("www:ram@gmail.com");
       RequestBuilder requestBuilder = MockMvcRequestBuilders.put("/e-dating/api/v1/interests/update")
               .content(MasterData.asJsonString(interestsDto)).contentType(MediaType.APPLICATION_JSON)
               .accept(MediaType.APPLICATION_JSON);

       MvcResult result = mockMvc.perform(requestBuilder).andReturn();
       yakshaAssert(currentTest(),
				(result.getResponse().getStatus() == HttpStatus.BAD_REQUEST.value() ? "true" : "false"),
				exceptionTestFile);

   }

 

}
