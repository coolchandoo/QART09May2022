package com.iiht.training.datingapp.functional;

import static com.iiht.training.datingapp.testutils.TestUtils.businessTestFile;
import static com.iiht.training.datingapp.testutils.TestUtils.exceptionTestFile;
import static com.iiht.training.datingapp.testutils.TestUtils.currentTest;
import static com.iiht.training.datingapp.testutils.TestUtils.testReport;
import static com.iiht.training.datingapp.testutils.TestUtils.yakshaAssert;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.iiht.training.datingapp.controller.UserRestController;
import com.iiht.training.datingapp.dto.UserDto;
import com.iiht.training.datingapp.filter.Filter;
import com.iiht.training.datingapp.filter.Filter.FilterType;
import com.iiht.training.datingapp.service.UserService;
import com.iiht.training.datingapp.testutils.MasterData;

@WebMvcTest(UserRestController.class)
@AutoConfigureMockMvc
public class UserRestControllerTest {
	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private UserService userService;
	
	@Mock
	private UserService mockUserService;

	@AfterAll
	public static void afterAll() {
		testReport();
	}

	@Test
	 void testRegisterUser() throws Exception {
		UserDto userDto = MasterData.getUserDto();
		UserDto savedUserDto = MasterData.getUserDto();
		when(this.userService.registerUser(userDto)).thenReturn(savedUserDto);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post("/e-dating/api/v1/users/register-user").content(MasterData.asJsonString(userDto))
				.contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON);

		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		yakshaAssert(currentTest(),
				(result.getResponse().getContentAsString().contentEquals(MasterData.asJsonString(savedUserDto)) ? "true"
						: "false"),
				businessTestFile);

	}


	@Test
	 void testGetAllUsers() throws Exception {
		List<UserDto> users = MasterData.getUserDtoList();

		when(this.userService.findAll()).thenReturn(users);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/e-dating/api/v1/users/get/all").contentType(MediaType.APPLICATION_JSON)
				.accept(MediaType.APPLICATION_JSON);

		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		yakshaAssert(currentTest(),
				(result.getResponse().getContentAsString().contentEquals(MasterData.asJsonString(users)) ? "true"
						: "false"),
				businessTestFile);

	}

	
	
	@Test
	 void testGetAllPotentialMatches() throws Exception {
		List<UserDto> matches = MasterData.getUserDtoList();
		List<Filter> filters = new ArrayList<>();
		ArrayList<String> list = new ArrayList<>();
		list.add("Mumbai");
		filters.add(new Filter(FilterType.CITY,list));
		when(mockUserService.getPotentialMatches("Chandu", filters)).thenReturn(matches);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post("/e-dating/api/v1/matches/Chandu").content(MasterData.asJsonString(filters)).contentType(MediaType.APPLICATION_JSON)
				.accept(MediaType.APPLICATION_JSON);
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		System.out.println("resu"+result.getResponse().getContentAsString());
		yakshaAssert(currentTest(),
				(result.getResponse().getStatus() == HttpStatus.BAD_REQUEST.value() ? "true" : "false"),
				exceptionTestFile);

	}

	
	
	@Test
	 void testRegisterUserInvalidDataException() throws Exception {
		UserDto userDto = MasterData.getUserDto();
		UserDto savedUserDto = MasterData.getUserDto();	
		userDto.setUserName("Cha");
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post("/e-dating/api/v1/users/register-user").content(MasterData.asJsonString(userDto))
				.contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON);
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		yakshaAssert(currentTest(),
				(result.getResponse().getStatus() == HttpStatus.BAD_REQUEST.value() ? "true" : "false"),
				exceptionTestFile);

	}
	
	@Test
	 void testErrorInvalidDataException() throws Exception {
		UserDto userDto = MasterData.getUserDto();
		userDto.setPassword(null);	
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post("/e-dating/api/v1/users/register-user").content(MasterData.asJsonString(userDto))
				.contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON);
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		
		yakshaAssert(currentTest(),
				(result.getResponse().getStatus() == HttpStatus.BAD_REQUEST.value() ? "true" : "false"),
				exceptionTestFile);

	}
	
	@Test
	 void testgetMatches() throws Exception {		
		List<UserDto> matches = new ArrayList<>();
		List<Filter> filters = new ArrayList<>();
		ArrayList<String> list = new ArrayList<>();
		list.add("Mumbai");
		filters.add(new Filter(FilterType.CITY,list));
		when(userService.getPotentialMatches("Chandu", filters)).thenReturn(matches);
		RequestBuilder requestBuilder = MockMvcRequestBuilders.post("/e-dating/api/v1/matches/Chandu").content(MasterData.asJsonString(filters))
				.contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON);
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		
		yakshaAssert(currentTest(),
				(result.getResponse().getStatus() == HttpStatus.BAD_REQUEST.value() ? "true" : "false"),
				exceptionTestFile);

	}
	
	

	

}
