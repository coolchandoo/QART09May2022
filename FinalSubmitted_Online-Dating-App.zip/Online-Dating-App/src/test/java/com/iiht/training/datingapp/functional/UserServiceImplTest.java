package com.iiht.training.datingapp.functional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatExceptionOfType;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThrows;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.iiht.training.datingapp.dto.UserDto;
import com.iiht.training.datingapp.entity.Interests;
import com.iiht.training.datingapp.entity.User;
import com.iiht.training.datingapp.exceptions.InvalidDataException;
import com.iiht.training.datingapp.filter.Filter;
import com.iiht.training.datingapp.filter.Filter.FilterType;
import com.iiht.training.datingapp.repository.InterestsRepository;
import com.iiht.training.datingapp.repository.UserRepository;
import com.iiht.training.datingapp.service.UserService;
import com.iiht.training.datingapp.service.impl.LocationServiceApiImpl;
import com.iiht.training.datingapp.service.impl.UserServiceImpl;
import com.iiht.training.datingapp.testutils.MasterData;

@ExtendWith(MockitoExtension.class)
class UserServiceImplTest {

	@Mock
	UserRepository user;
	@InjectMocks
	UserServiceImpl userimpl;
	@Mock
	LocationServiceApiImpl locationserv;
	@Mock
	InterestsRepository interestRepo;
	
	@Mock
	UserServiceImpl mockUser;

	

	@Test
	void testRegisterUserService() throws Exception {
		UserDto userDto = MasterData.getUserDto();
		UserDto registerUser = userimpl.registerUser(userDto);
		assertEquals(registerUser, userDto);
	}

	@Test
	void testUpdateInterestIsServiceMethodCalledInvaidData() throws Exception {
		assertThatExceptionOfType(InvalidDataException.class).isThrownBy(() -> userimpl.registerUser(null))
				.withMessage("Invalid data");
	}

	@Test
	void testPotentialMatch() throws Exception {
		List<UserDto> matches = MasterData.getUserDtoList();
		List<Filter> filters = new ArrayList<>();
		ArrayList<String> list = new ArrayList<>();
		list.add("Mumbai");
		filters.add(new Filter(FilterType.CITY,list));
		List<Filter> filteList = MasterData.getFilteList();
		User userRecord = new User();
		userRecord.setUserName("Chandu");		
		when(user.findbyuserName("Chandu")).thenReturn(userRecord);
		when(locationserv.getUsersDto(filters)).thenReturn(matches);
		List<UserDto> potentialMatches = userimpl.getPotentialMatches("Chandu", filters);
	    assertEquals(potentialMatches.size(), matches.size());
	}

	@Test
	void testPotentialMatchInvaidData() throws Exception {
		List<Filter> filteList = MasterData.getFilteList();
		assertThatExceptionOfType(InvalidDataException.class)
				.isThrownBy(() -> userimpl.getPotentialMatches(null, filteList)).withMessage("Invalid User Id");
	}

	@Test
	void testFindAll() throws Exception {
		List<User> u = new ArrayList<>();
		User uk = new User();
		uk.setAge(22);
		uk.setUserName("Chandu");
		u.add(uk);		
		uk = new User();
		uk.setCity("Rampur");
		uk.setUserName("Chandu");
		u.add(uk);
		Interests inter = new Interests();
		inter.setAbout("");
		inter.setInterestId(2L);
		when(user.findAll()).thenReturn(u);
		when(user.findInterestByUserName("Chandu")).thenReturn(2L);
		when(interestRepo.findbyInterestId(2L)).thenReturn(inter);
		List<UserDto> findAll = userimpl.findAll();		
		assertThat(findAll).isNotNull();
		assertThat(findAll).isNotEmpty();
		
	}
	
	
	
	
	
}
