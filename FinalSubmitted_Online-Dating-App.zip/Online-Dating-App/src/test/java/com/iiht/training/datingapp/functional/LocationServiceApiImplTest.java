package com.iiht.training.datingapp.functional;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import com.iiht.training.datingapp.dto.UserDto;
import com.iiht.training.datingapp.filter.Filter;
import com.iiht.training.datingapp.filter.Filter.FilterType;
import com.iiht.training.datingapp.service.UserService;
import com.iiht.training.datingapp.service.impl.LocationServiceApiImpl;

@ExtendWith(MockitoExtension.class)
public class LocationServiceApiImplTest {

	@InjectMocks
	LocationServiceApiImpl locationServiceApiImpl;
	
	@Mock
	UserService userService;
	
	@Test
	public void testGetUsersDto() {
		
		UserDto userDto = new UserDto();
		userDto.setAge(22);
		userDto.setCity("Bangalore");
		userDto.setEmail("test@gmail.com");
		userDto.setCountry("India");
		userDto.setGender("Male");
		userDto.setUserName("Test");
		List<UserDto> userDtoList = new ArrayList<UserDto>();
		userDtoList.add(userDto);
		
		
		Mockito.when(userService.findAll()).thenReturn(userDtoList);
		

		List<Filter> filters = new ArrayList<Filter>();
		Filter filter = new Filter();
		filter.setType(FilterType.AGE);
		List<Integer> values = new  ArrayList<Integer>();
		values.add(20);
		values.add(34);
		filter.setValues(values);
		
		filters.add(filter);
		
		List<UserDto> returnList = locationServiceApiImpl.getUsersDto(filters);
		assertEquals(returnList.get(0).getAge(), 22);
		
		List<Filter> filtersCity = new ArrayList<Filter>();
		Filter filterCity = new Filter();
		filterCity.setType(FilterType.CITY);
		List<String> valuescity = new  ArrayList<String>();
		valuescity.add("Bangalore");
		valuescity.add("Hyderabad");
		filterCity.setValues(valuescity);
		
		filtersCity.add(filterCity);
					
		List<UserDto> returnListcity = locationServiceApiImpl.getUsersDto(filtersCity);
		assertEquals(returnListcity.get(0).getCity(), "Bangalore");
		
		List<Filter> filtersContry = new ArrayList<Filter>();
		Filter filterCountry = new Filter();
		filterCountry.setType(FilterType.COUNTRY);
		List<String> valuesCountry = new  ArrayList<String>();
		valuesCountry.add("India");
		//valuesCountry.add("Hyderabad");
		filterCountry.setValues(valuesCountry);
		
		filtersContry.add(filterCountry);
					
		List<UserDto> returnListcontry = locationServiceApiImpl.getUsersDto(filtersContry);
		assertEquals(returnListcontry.get(0).getCountry(), "India");
		
		List<Filter> filtersGender = new ArrayList<Filter>();
		Filter filterGender = new Filter();
		filterGender.setType(FilterType.GENDER);
		List<String> valuesGender = new  ArrayList<String>();
		valuesGender.add("Male");
		//valuesGender.add("Female");
		filterGender.setValues(valuesGender);
		
		filtersGender.add(filterGender);
					
		List<UserDto> returnListGender = locationServiceApiImpl.getUsersDto(filtersGender);
		assertEquals(returnListGender.get(0).getGender(), "Male");
		
		Filter filterContru = new Filter(FilterType.AGE, valuesGender);
		assertEquals(filterContru.getType(), FilterType.AGE);
		
	}
	

	@Test
	public void testGetUsersDto_filter_null() {
		UserDto userDto = new UserDto();
		userDto.setAge(22);
		userDto.setCity("Bangalore");
		userDto.setEmail("test@gmail.com");
		userDto.setCountry("India");
		userDto.setGender("Male");
		userDto.setUserName("Test");
		List<UserDto> userDtoList = new ArrayList<UserDto>();
		userDtoList.add(userDto);
		
		List<Filter> filters = null;
		
		Mockito.when(userService.findAll()).thenReturn(userDtoList);

		List<UserDto> retrun = locationServiceApiImpl.getUsersDto(filters);
		assertEquals(retrun.size(), 1);
	}
	
	
	@Test
	public void testGetUsersDto_filter_Empty() {
		UserDto userDto = new UserDto();
		userDto.setAge(22);
		userDto.setCity("Bangalore");
		userDto.setEmail("test@gmail.com");
		userDto.setCountry("India");
		userDto.setGender("Male");
		userDto.setUserName("Test");
		List<UserDto> userDtoList = new ArrayList<UserDto>();
		userDtoList.add(userDto);
		
		List<Filter> filters = new ArrayList<Filter>();
		
		Mockito.when(userService.findAll()).thenReturn(userDtoList);

		List<UserDto> retrun = locationServiceApiImpl.getUsersDto(filters);
		assertEquals(retrun.size(), 1);
	}
	
}
