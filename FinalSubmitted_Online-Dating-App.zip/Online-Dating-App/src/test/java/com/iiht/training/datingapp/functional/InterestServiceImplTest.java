package com.iiht.training.datingapp.functional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatExceptionOfType;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.iiht.training.datingapp.dto.InterestsDto;
import com.iiht.training.datingapp.entity.Interests;
import com.iiht.training.datingapp.entity.User;
import com.iiht.training.datingapp.exceptions.InvalidDataException;
import com.iiht.training.datingapp.repository.InterestsRepository;
import com.iiht.training.datingapp.repository.UserRepository;
import com.iiht.training.datingapp.service.impl.InterestsServiceImpl;
import com.iiht.training.datingapp.testutils.MasterData;

@ExtendWith(MockitoExtension.class)
class InterestServiceImplTest {
	@Mock
	InterestsRepository interestRepo;

	@Mock
	UserRepository userRepo;

	@InjectMocks
	private InterestsServiceImpl interestsServiceImpl;

	

	@Test
	void testUpdateInterest() throws Exception {
		InterestsDto interestsDto = MasterData.getInterestsDto();
		InterestsDto interestsDto2 = MasterData.getInterestsDto();
		User u = new User();
		u.setUserName("Ram");
		Interests inter = new Interests();
		inter.setUserName("Suraj");
		when(userRepo.findbyuserName(interestsDto.getUserName())).thenReturn(u);
		when(interestRepo.findbyInterestId(interestsDto.getInterestId())).thenReturn(inter);
		
		InterestsDto updateInterest = interestsServiceImpl.updateInterest(interestsDto);
		assertEquals(updateInterest.getUserName() != null, interestsDto2.getUserName() != null);

	}

	@Test
	void testdeleteInterest() throws Exception {
		boolean deleteInterest = interestsServiceImpl.deleteInterest(1L);
		if (deleteInterest) {
			assertTrue(deleteInterest);
		}
	}

	@Test
	void testdeleteInterestInvalidID() throws Exception {
		boolean deleteInterest = interestsServiceImpl.deleteInterest(0L);
		if (!deleteInterest) {
			assertFalse(deleteInterest);
		}

	}

	@Test
	void testUpdateInterestNullCheck() throws Exception {
		InterestsDto interestsDto = new InterestsDto();
		interestsDto.setInterestId(0L);
		assertThatExceptionOfType(InvalidDataException.class)
				.isThrownBy(() -> interestsServiceImpl.updateInterest(interestsDto)).withMessage("Not a valid Data");

	}

}
