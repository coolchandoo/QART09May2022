package com.iiht.training.datingapp.testutils;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.iiht.training.datingapp.dto.InterestsDto;

import com.iiht.training.datingapp.dto.UserDto;
import com.iiht.training.datingapp.filter.Filter;
import com.iiht.training.datingapp.filter.Filter.FilterType;

public class MasterData {

	public static UserDto getUserDto() {
		UserDto user = new UserDto();
		InterestsDto interestDTO = new InterestsDto();
		interestDTO.setAbout("i'm good");
		interestDTO.setHobbies(List.of("A","B"));
		interestDTO.setLikes("Cooking");
		interestDTO.setDislikes("Fighting");
		interestDTO.setProfileUrl("www.h@gmail.com");
		interestDTO.setUserName("Karthi");		
		user.setUserName("Karthi");
		user.setEmail("www.name@mail.com");
		user.setAge(22);
		user.setGender("Male");
		user.setPhoneNumber(1234567890L);
		user.setCity("Mumbai");
		user.setCountry("India");
		user.setInterests(interestDTO);
		user.setPassword("Passert45");
		return user;

	}

	public static List<UserDto> getUserDtoList() {
		List<UserDto> users = new ArrayList<>();
		UserDto user = new UserDto();
		user.setUserName("Sultan");		
		user.setEmail("first@mail.com");
		user.setAge(22);
		user.setGender("Male");
		user.setPhoneNumber(1234567890L);
		user.setCity("Mumbai");
		user.setCountry("India");
		users.add(user);
		user = new UserDto();
		user.setUserName("Rahim");
	
		user.setEmail("second@mail.com");
		user.setAge(23);
		user.setGender("Female");
		user.setPhoneNumber(99994567890L);
		user.setCity("London");
		user.setCountry("England");
		users.add(user);
		return users;
	}

	public static InterestsDto getInterestsDto() {

		InterestsDto interestDto = new InterestsDto();
		interestDto.setInterestId(123L);
		interestDto.setUserName("Ram");
		List<String> hobbies = new ArrayList<>();
		hobbies.add("Playing Cricket");
		hobbies.add("Reading Books");
		hobbies.add("Travelling");
		interestDto.setHobbies(hobbies);
		interestDto.setLikes("To Talk");
		interestDto.setDislikes("Getting up early in the morning");
		interestDto.setProfileUrl("http.abc.com");
		interestDto.setAbout("I am a Simple man");
		return interestDto;
	}

	public static List<InterestsDto> getInterestsDtoList() {
		List<InterestsDto> interests = new ArrayList<>();
		InterestsDto interestDto = new InterestsDto();
		interestDto.setInterestId(1L);
		interestDto.setUserName("Lal");
		List<String> hobbies = new ArrayList<>();
		hobbies.add("Playing Cricket");
		hobbies.add("Reading Books");
		hobbies.add("Travelling");
		interestDto.setHobbies(hobbies);
		interestDto.setLikes("To Talk");
		interestDto.setDislikes("Getting up early in the morning");
		interestDto.setProfileUrl("www.abc.com");
		interestDto.setAbout("I am a Simple man");
		interests.add(interestDto);
		interestDto = new InterestsDto();
		interestDto.setInterestId(2L);
		interestDto.setUserName("Giri");
		hobbies = new ArrayList<>();
		hobbies.add("Sleeping");
		hobbies.add("Playing Games");
		interestDto.setHobbies(hobbies);
		interestDto.setLikes("Riding the Bikes");
		interestDto.setDislikes("Sleeping early");
		interestDto.setProfileUrl("www.example.com");
		interestDto.setAbout("Have passion for life");
		interests.add(interestDto);
		return interests;
	}
	
	public static List<Filter> getFilteList() {
		List<Filter> filters = new ArrayList<>();
		Filter fil = new Filter();
		fil.setType(FilterType.AGE);
		fil.setValues(List.of(18,20,22));
		filters.add(fil);
		return filters;
	}

	public static String asJsonString(final Object obj) {
		try {
			final ObjectMapper mapper = new ObjectMapper();
			final String jsonContent = mapper.writeValueAsString(obj);
			return jsonContent;
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
}
